<?php
 $conexion=mysqli_connect("localhost","sourcedartnew","iGNT^Y6gwq6a","sourcedartnew_smedian2022") or die("problem de conextion");
// $conexion=mysqli_connect("localhost","root","","smedian") or die("problem de conextion");
 mysqli_query($conexion,"set character_set_server='utf8'");
 mysqli_query($conexion,"set names 'utf8'");

?>